export const dataComments = [
	{id: 1, user_id: 1, date: "2020-05-10 11:45", text: "Greetings, fellow colleagues. I would like to share my insights on this task. I reckon we should deal with at least half of the points in the plan without further delays. I suggest proceeding from one point to the next and notifying the rest of us with at least short notices. This way is best to keep track of who is doing what."},
	{id: 2, user_id: 2, date: "2020-05-12 12:01", text: "Hi, Corvo. I am sure that that's exactly what is thought best out there in Dunwall. Let's just do what we are supposed to do to get the result."},
	{id: 3, user_id: 3, date: "2020-05-12 12:10", text: "One more question, guys. Did you see Webix Document Manager? I think it can help us in planning our own work. https://webix.com/assets/documentmanager/Preview@2x.png"},
	{id: 4, user_id: 2, date: "2020-05-14 12:15", text: "Wow great, could you please share a link to this tool? Cannot wait for playing around with it."}
];
