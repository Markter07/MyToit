export const dataUsers = [
	{id: 1, value: "Corvo Attano", image: "./assets/img/corvo.jpg", status: "busy"},
	{id: 2, value: "Daisy Fitzroy", image: "./assets/img/daisy.jpg", status: "active"},
	{id: 3, value: "Me", image: "./assets/img/me.jpg", status: "away"},
	{id: 4, value: "Kurt Cobain", image: "./assets/img/me.jpg", status: "none"},
	{id: 5, value: "Robert Smith", image: "./assets/img/me.jpg", status: "active"},
	{id: 6, value: "Kurt Cobain", image: "./assets/img/me.jpg", status: "away"}
];
