export const dataConv = [
	{id: 1, name: "Conversation", photo: "conversation.jpg", message: "Alex: I would like to share my project with team", date: "12:45", unread: 5},
	{id: 2, name: "Team Chat", photo: "team_chat.jpg", message: "Daisy Fitzroy: Wow great, how about meeting today at 12.00?", date: "14:20", unread: 0},
	{id: 3, name: "Meeting Chat", photo: "meeting_chat.jpg", message: "You: Feel free to ask any questions about project", date: "14:45", unread: 0}
];
